#!/bin/bash

cd /home/ctf
python3 server.py
